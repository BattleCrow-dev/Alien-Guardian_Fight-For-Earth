public interface IDamageable
{
    public void SetDamage(float damage);
    public float GetDamage();
}
