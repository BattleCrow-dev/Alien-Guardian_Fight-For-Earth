using System;
using UnityEngine;

[Serializable]
public class CutScene
{
    public Transform Target;
    public string Text;
    public float Delay;
    public AudioClip Voice;
}
